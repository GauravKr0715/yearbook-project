import React from 'react'
import "./Nav.css"
import { Navbar } from 'react-bootstrap'

function Nav() {
    return (
        <div>
        <Navbar variant='dark' className="nav"  sticky="top">
        <Navbar.Brand href="/">Home</Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse className="justify-content-end">
          <Navbar.Text>
            Signed in as: <a href="#login">Mark Otto</a>
          </Navbar.Text>
        </Navbar.Collapse>
      </Navbar>     
        </div>
    )
}

export default Nav
