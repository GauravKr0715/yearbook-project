import React, { useState, useEffect } from 'react'
import Nav from "../components/Nav"

import "./Photo.css"
function Photo() {

    const [profileImg, setProfileImg] = useState("https://jpublicrelations.com/wp-content/uploads/2015/12/placeholder-1.png.1236x617_default.png");

    
        
       
        const imageHandler = (e) => {
            const reader= new FileReader()
            reader.onload=()=>{
                if(reader.readyState===2){
                    setProfileImg(reader.result);
                }
    
            }
            reader.readAsDataURL(e.target.files[0]);
        }
    
        return (
            
            <div >
            <Nav />
             
                 <div className="container">
                  <div className="dp">
                    <img src={profileImg} id="pro" className="img" accept="image/*"  />
                     
    
                  <input type="file" className="file"  id="input" accept="image/*" onChange={imageHandler}/>
                  <div className="label" >
                  <label htmlFor="input" className="upl">
                  Upload Pic
                  </label>
                  </div>
                  
                  <div className="p">
                  <p>
                     "All kinds of first time in life are sometimes experience with college friends.So let's make it more memorable by uploading your Group Photo or Collage..

                     "
                  </p>
                  </div>
        </div>
        </div>
        </div>
    )
}

export default Photo
