import React from 'react'
import Nav from "../components/Nav"
import "./All.css"
function CommentW() {
    return (
        <div>
        <Nav/>
        </div>
    )
}

export default CommentW
