import React, { useState, useEffect } from 'react'
import Nav from "../components/Nav"
import "./ProfileFunc.css"

const ProfileFunc = () => {
    const [isEditable, setIsEditable] = useState(false);
    useEffect(() => {
        //
    }, [isEditable]);

    const [quote, setQuote] = useState('Some Quote...');

    const [profileImg, setProfileImg] = useState('https://th.bing.com/th/id/OIP.OesLvyzDO6AvU_hYUAT4IAHaHa?pid=ImgDet&rs=1');

    const imageHandler = (e) => {
        const reader= new FileReader()
        reader.onload=()=>{
            if(reader.readyState===2){
                setProfileImg(reader.result);
            }

        }
        reader.readAsDataURL(e.target.files[0])
    }

    return (
        
        <div >
        <Nav />
         
             <div className="container">
              <div className="dpic">
                <img src={profileImg} id="pro" className="image" accept="image/*"  />
                 

              <input type="file" className="file"  id="input" accept="image/*" onChange={imageHandler}/>
              <div className="label" >
              <label htmlFor="input" className="upl">
              Change pic
              </label>
              </div>
              

              <div className="Q">
                  
              {
                isEditable ? (
                    <>
                    <input id='quote' type='text' placeholder='"Some Quote...."' className="qoute" /><br></br>
                    <button onClick={() => {
                        // alert(document.getElementById('quote').value);
                        setQuote(document.getElementById('quote').value);
                        setIsEditable(false);
                    }} className="btnS">Save</button>
                    </>
                ) : (
                    <>
                    <p className="par">{quote}</p>
                    <button onClick={() => {
                        setIsEditable(true);
                    }} className="btnE">Edit</button>
                    </>
                )
              }
              
              </div>
              </div>
            </div>
            </div>
    );
}

export default ProfileFunc;
