import React from 'react';

import './LoginFun.css';

const Login = () => {

    return (
      <div className="bag">
        <section id="entry-page">
        <form className="form">
          
          <div className="field">
            <h1>Log In</h1>
            <ul>
              <li>
                <label for="username">Username:</label><br></br>
                <input type="text" id="username" required/>
              </li>
              <li>
                <label for="password">Password:</label><br></br>
                <input type="password" id="password" required/>
              </li>
             
            </ul>
          </div>
          <button>Login</button>
          
        </form>
      </section>
        </div>
      )

}

export default Login;